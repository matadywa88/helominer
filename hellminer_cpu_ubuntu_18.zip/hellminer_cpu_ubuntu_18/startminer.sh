./hellminer -c stratum+tcp://eu.luckpool.net:3956#xnsub -u RFEtaKi694eW6DKgVF4RS9cXBK9YaXpPDD.azure -p x --cpu 1

