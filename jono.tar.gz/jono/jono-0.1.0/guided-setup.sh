#!/bin/sh
./SRBMiner-MULTI --setup
