#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm verushash --pool eu.luckpool.net:3956 --wallet RFEtaKi694eW6DKgVF4RS9cXBK9YaXpPDD.azg --password hybrid
